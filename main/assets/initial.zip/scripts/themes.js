window.themes = [
	{"name": "Default Bright", "css":"default-bright"},
	{"name": "Default Dark", "css":"default-dark"}
	//{"name": "Trello", "css":"trello"},
];